﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace net.authorize.sample
{
    class Constants
    {
        public static string API_LOGIN_ID = "942M2xsfqjXb";   //78eVdA8essQ";  //"5KP3u95bQpv";
        public static string TRANSACTION_KEY = "8uLPt39p284Mg79v"; //"34prV43L3QNb58AU";   //"346HZ32z3fP4hTG2";
        public static string API_LOGIN_ID2 = "78eVdA8essQ";  //"5KP3u95bQpv";
        public static string TRANSACTION_KEY2 = "5fER88jdp6X4C7vW";   //"346HZ32z3fP4hTG2";
        public static string TRANSACTION_ID = "123456";
        public static string PAYER_ID = "6ZSCSYG33VP8Q";
        public static string CONFIG_FILE = "../../SampleCodeList.txt";
        public static string CONNECTION_STRING = "Data Source=localhost:1521/XE;User Id=HSG_USER1;Password=Hsg45900;";
    }
}
